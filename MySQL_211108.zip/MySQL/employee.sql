INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1001, '张三', '男', '2020-06-10', 2000, 200, 500, '营销部');
INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1002, '李四', '男', '2020-10-01', 4000, 300, NULL, '营销部');
INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1003, '王五', '女', '2021-01-28', 3000, 100, 1000, '研发部');
INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1004, '赵六', '男', '2020-09-17', 4500, 200, 800, '财务部');
INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1005, '孙七', '女', '2020-11-03', 7000, 370, NULL, NULL);
INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1006, '周八', '男', '2021-03-11', 1000, 60, 70, '人事部');
INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1007, '吴九', '女', '2020-05-26', 15000, 780, NULL, '研发部');
INSERT INTO `employee` (`id`, `name`, `gender`, `hired_date`, `salary`, `performance`, `manage`, `department`) VALUES (1008, '郑十', '女', '2020-12-15', 3500, 400, NULL, '人事部');
